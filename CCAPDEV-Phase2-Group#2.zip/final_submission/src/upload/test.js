import multer from 'multer';


const testupload = multer();
export default testupload;